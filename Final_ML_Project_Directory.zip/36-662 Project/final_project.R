# ---------------------------- data prep --------------------------------------

library(dplyr)
library(lubridate)

# Load CSV files
df_2022 <- read.csv("flights2022.csv")
df_2023 <- read.csv("flights2023.csv")

# Combine, parse FL_DATE properly, and sort
df_all <- bind_rows(df_2022, df_2023) %>%
  mutate(FL_DATE = mdy_hms(FL_DATE)) %>%  
  arrange(FL_DATE)

# 80% sequential split
split_index <- floor(0.8 * nrow(df_all))
train_df <- df_all[1:split_index, ]
val_df   <- df_all[(split_index + 1):nrow(df_all), ]

# Save
write.csv(train_df, "full_data_train.csv", row.names = FALSE)
write.csv(val_df, "full_data_val.csv", row.names = FALSE)



library(lubridate)
library(dplyr)

visible_2024 <- read.csv("flights2024_visible.csv")
guess_2024   <- read.csv("flights2024_guess.csv")

# Convert FL_DATE from character to POSIXct using mdy_hms
visible_2024 <- visible_2024 %>%
  mutate(FL_DATE = mdy_hms(FL_DATE))

guess_2024 <- guess_2024 %>%
  mutate(FL_DATE = mdy_hms(FL_DATE))

write.csv(visible_2024, "flights2024_visible_clean.csv", row.names = FALSE)
write.csv(guess_2024, "flights2024_guess_clean.csv", row.names = FALSE)





# ---------------------------- data prep 2 --------------------------------------

train_df <- read.csv("full_data_train.csv")
val_df <- read.csv("full_data_val.csv")
visible_2024 <- read.csv("flights2024_visible_clean.csv")
guess_2024   <- read.csv("flights2024_guess_clean.csv")

# Forbidden columns from instructions
banned_cols <- c(
  "DEP_TIME", "DEP_DELAY", "DEP_DELAY_NEW", "DEP_DELAY_GROUP", "DEP_TIME_BLK",
  "TAXI_OUT", "WHEELS_OFF", "WHEELS_ON", "TAXI_IN",
  "ARR_TIME", "ARR_DELAY", "ARR_DELAY_NEW", "ARR_DEL15", "ARR_DELAY_GROUP", "ARR_TIME_BLK",
  "CANCELLED", "CANCELLATION_CODE", "DIVERTED",
  "ACTUAL_ELAPSED_TIME", "AIR_TIME",
  "CARRIER_DELAY", "WEATHER_DELAY", "NAS_DELAY", "SECURITY_DELAY", "LATE_AIRCRAFT_DELAY",
  "FIRST_DEP_TIME", "TOTAL_ADD_GTIME", "LONGEST_ADD_GTIME"
)

# Time binning helper function
convert_time_to_factor <- function(time_hhmm) {
  time_minutes <- (as.numeric(time_hhmm) %/% 100) * 60 + (as.numeric(time_hhmm) %% 100)
  cut(
    time_minutes,
    breaks = c(0, 6*60, 9*60, 12*60, 15*60, 18*60, 21*60, 24*60),
    labels = c("early_morning", "morning_rush", "midday",
               "afternoon", "evening_rush", "evening", "night"),
    include.lowest = TRUE
  )
}

# Robust FL_DATE parsing
clean_flight_data <- function(df) {
  df <- df[, !(names(df) %in% banned_cols)]
  
  # Fix FL_DATE format (only if not Date already)
  if (!inherits(df$FL_DATE, "Date")) {
    df$FL_DATE <- suppressWarnings(as.Date(df$FL_DATE))  # assume YYYY-MM-DD
  }
  
  # Create time features
  df$DEP_TIME_MIN <- (df$CRS_DEP_TIME %/% 100) * 60 + (df$CRS_DEP_TIME %% 100)
  df$DEP_TIME_BIN <- convert_time_to_factor(df$CRS_DEP_TIME)
  
  df$ARR_TIME_MIN <- (df$CRS_ARR_TIME %/% 100) * 60 + (df$CRS_ARR_TIME %% 100)
  df$ARR_TIME_BIN <- convert_time_to_factor(df$CRS_ARR_TIME)
  
  return(df)
}


# Apply to all datasets
train_clean <- clean_flight_data(train_df)
val_clean   <- clean_flight_data(val_df)
visible_2024_clean <- clean_flight_data(visible_2024)
guess_2024_clean   <- clean_flight_data(guess_2024)


# ---------------------------- eda --------------------------------------
library(dplyr)
library(ggplot2)
library(scales)

# --- Delay Rate by Time of Day Bin ---
train_clean %>%
  filter(!is.na(DEP_DEL15)) %>%
  group_by(DEP_TIME_BIN) %>%
  summarise(delay_rate = mean(DEP_DEL15), count = n()) %>%
  ggplot(aes(x = DEP_TIME_BIN, y = delay_rate)) +
  geom_col(fill = "steelblue") +
  geom_text(aes(label = percent(delay_rate, accuracy = 0.1)), vjust = -0.5) +
  labs(
    title = "Delay Rate by Scheduled Departure Time Bin (Training Set)",
    x = "Time of Day",
    y = "Proportion of Flights Delayed 15+ min"
  ) +
  theme_minimal()

# --- Smooth Delay Trend Over Day ---
train_clean %>%
  filter(!is.na(DEP_DEL15)) %>%
  group_by(DEP_TIME_MIN) %>%
  summarise(delay_rate = mean(DEP_DEL15)) %>%
  ggplot(aes(x = DEP_TIME_MIN, y = delay_rate)) +
  geom_line(color = "tomato", size = 1) +
  labs(
    title = "Delay Rate vs. Scheduled Departure Time (Training Set)",
    x = "Scheduled Departure Time (minutes since midnight)",
    y = "Delay Rate (DEP_DEL15)"
  ) +
  theme_minimal()

# --- Heatmap: Day of Week vs. Time Bin ---
train_clean %>%
  filter(!is.na(DEP_DEL15)) %>%
  group_by(DAY_OF_WEEK, DEP_TIME_BIN) %>%
  summarise(delay_rate = mean(DEP_DEL15)) %>%
  ggplot(aes(x = DEP_TIME_BIN, y = factor(DAY_OF_WEEK))) +
  geom_tile(aes(fill = delay_rate)) +
  scale_fill_gradient(low = "lightyellow", high = "red") +
  labs(
    title = "Delay Rate by Day of Week and Time of Day (Training Set)",
    x = "Departure Time Bin",
    y = "Day of Week (1 = Monday, 7 = Sunday)",
    fill = "Delay Rate"
  ) +
  theme_minimal()

# --- Delay Rate by Day of Week ---
train_clean %>%
  filter(!is.na(DEP_DEL15)) %>%
  group_by(DAY_OF_WEEK) %>%
  summarise(delay_rate = mean(DEP_DEL15), count = n()) %>%
  ggplot(aes(x = factor(DAY_OF_WEEK), y = delay_rate)) +
  geom_col(fill = "steelblue") +
  geom_text(aes(label = percent(delay_rate, accuracy = 0.1)), vjust = -0.5) +
  labs(
    title = "Delay Rate by Day of Week (Training Set)",
    x = "Day of Week (1 = Monday, 7 = Sunday)",
    y = "Proportion of Flights Delayed 15+ min"
  ) +
  theme_minimal()

# --- Delay Rate by Month ---
train_clean %>%
  filter(!is.na(DEP_DEL15)) %>%
  group_by(MONTH) %>%
  summarise(delay_rate = mean(DEP_DEL15)) %>%
  ggplot(aes(x = factor(MONTH), y = delay_rate)) +
  geom_col(fill = "darkorange") +
  geom_text(aes(label = percent(delay_rate, accuracy = 0.1)), vjust = -0.5) +
  labs(
    title = "Monthly Delay Rate (Training Set)",
    x = "Month",
    y = "Proportion of Flights Delayed 15+ min"
  ) +
  theme_minimal()


# ---------------------------------- feature engineering  ------------------------
# ---------------------------------- holidays  ------------------------

library(dplyr)
library(lubridate)
library(timeDate)
library(purrr)

# Get vector of US federal holidays for all relevant years
all_years <- unique(na.omit(c(
  year(train_clean$FL_DATE),
  year(val_clean$FL_DATE),
  year(visible_2024_clean$FL_DATE),
  year(guess_2024_clean$FL_DATE)
)))

us_holidays <- as.Date(holidayNYSE(all_years))

# Helper to create holiday-based features
add_holiday_features <- function(df) {
  df <- df %>%
    mutate(
      date = as.Date(FL_DATE),
      is_us_holiday = date %in% us_holidays,
      is_day_before_holiday = (date + 1) %in% us_holidays,
      is_day_after_holiday  = (date - 1) %in% us_holidays,
      is_long_weekend_start = (wday(date) %in% c(6, 7)) & ((date + 2) %in% us_holidays),  # Fri/Sat before Mon holiday
      is_long_weekend_end   = (wday(date) == 2) & ((date - 3) %in% us_holidays),          # Mon after Fri/Sat holiday
      week_of_holiday = map_lgl(date, ~ any((floor_date(.x, unit = "week") + 0:6) %in% us_holidays))
    ) %>%
    select(-date)  # Optional: remove helper column
  return(df)
}

# Apply holiday features to all datasets
train_clean <- add_holiday_features(train_clean)
val_clean   <- add_holiday_features(val_clean)
visible_2024_clean <- add_holiday_features(visible_2024_clean)
guess_2024_clean   <- add_holiday_features(guess_2024_clean)

# ---------------------------------- weather  ------------------------
datasets <- list(
  train = train_clean,
  val = val_clean,
  visible_2024 = visible_2024_clean,
  guess_2024 = guess_2024_clean
)

lapply(datasets, function(df) {
  range(df$FL_DATE)
})


library(readr)
library(dplyr)
library(lubridate)

# Load the two weather files
weather1 <- read_csv("pittsburgh 2022-01-01 to 2024-08-31.csv")
weather2 <- read_csv("pittsburgh 2024-09-01 to 2024-12-31.csv")

# Combine and clean
weather_all <- bind_rows(weather1, weather2) %>%
  mutate(
    date = as.Date(datetime),  # Create clean date column for merging
    is_rain = ifelse(precip > 0, 1, 0),
    is_snow = ifelse(snowdepth > 0 | conditions %in% c("Snow", "Snow, Overcast"), 1, 0)
  ) %>%
  select(
    date,
    tempmax, tempmin, temp,
    precip, snow, snowdepth,
    windspeed, cloudcover,
    conditions,
    is_rain, is_snow
  )


train_clean <- left_join(train_clean, weather_all, by = c("FL_DATE" = "date"))
val_clean <- left_join(val_clean, weather_all, by = c("FL_DATE" = "date"))
visible_2024_clean <- left_join(visible_2024_clean, weather_all, by = c("FL_DATE" = "date"))
guess_2024_clean <- left_join(guess_2024_clean, weather_all, by = c("FL_DATE" = "date"))



# ---------------------------------- random forest on 2022 only  ------------------------

library(randomForest)
library(pROC)
library(dplyr)
library(caret)
library(ggplot2)

# Ensure data is clean
target <- "DEP_DEL15"
predictors <- setdiff(names(train_clean), c(target, "FL_DATE", "TAIL_NUM"))

train_clean <- train_clean %>% filter(!is.na(DEP_DEL15)) %>% drop_na(all_of(predictors))
val_clean <- val_clean %>% filter(!is.na(DEP_DEL15)) %>% drop_na(all_of(predictors))
train_clean$DEP_DEL15 <- as.factor(train_clean$DEP_DEL15)
val_clean$DEP_DEL15 <- as.factor(val_clean$DEP_DEL15)

# Match factor levels
for (col in predictors) {
  if (is.factor(train_clean[[col]])) {
    val_clean[[col]] <- factor(val_clean[[col]], levels = levels(train_clean[[col]]))
  }
}

# Hyperparameter tuning grid
param_grid <- expand.grid(
  mtry = c(4, 6, 8, 10),
  nodesize = c(1, 5, 10)
)
param_grid$train_auc <- NA
param_grid$val_auc <- NA
param_grid$mean_auc <- NA

# Tune model
for (i in 1:nrow(param_grid)) {
  m <- param_grid$mtry[i]
  n <- param_grid$nodesize[i]
  
  model <- randomForest(DEP_DEL15 ~ ., data = train_clean[, c(predictors, target)],
                        mtry = m, nodesize = n, ntree = 200, importance = TRUE)
  
  train_probs <- predict(model, newdata = train_clean, type = "prob")[, 2]
  val_probs <- predict(model, newdata = val_clean, type = "prob")[, 2]
  
  param_grid$train_auc[i] <- auc(train_clean$DEP_DEL15, train_probs)
  param_grid$val_auc[i] <- auc(val_clean$DEP_DEL15, val_probs)
  param_grid$mean_auc[i] <- mean(c(param_grid$train_auc[i], param_grid$val_auc[i]))
}

# Best model selection
best <- param_grid %>% arrange(desc(val_auc)) %>% slice(1)
print(best)

rf_final <- randomForest(DEP_DEL15 ~ ., data = train_clean[, c(predictors, target)],
                         mtry = best$mtry, nodesize = best$nodesize, ntree = 200, importance = TRUE)

val_probs <- predict(rf_final, newdata = val_clean, type = "prob")[, 2]
val_preds <- factor(ifelse(val_probs >= 0.5, "1", "0"), levels = c("0", "1"))
actual <- val_clean$DEP_DEL15

# Metrics
cm <- confusionMatrix(val_preds, actual, positive = "1")
auc_val <- auc(actual, val_probs)
train_auc <- auc(train_clean$DEP_DEL15, predict(rf_final, newdata = train_clean, type = "prob")[, 2])

print(cm$table)
cat("\nTrain AUC:", round(train_auc, 4), "\n")
cat("Validation AUC:", round(auc_val, 4), "\n")
cat("Accuracy:", round(cm$overall["Accuracy"], 4), "\n")
cat("Precision:", round(cm$byClass["Precision"], 4), "\n")
cat("Recall:", round(cm$byClass["Recall"], 4), "\n")
cat("F1 Score:", round(cm$byClass["F1"], 4), "\n")

# Histogram plot
val_clean$predicted_prob <- val_probs
val_clean$actual_label <- actual

ggplot(val_clean, aes(x = predicted_prob, fill = actual_label)) +
  geom_histogram(binwidth = 0.025, position = "identity", alpha = 0.6, color = "black") +
  scale_fill_manual(values = c("0" = "lightgreen", "1" = "salmon"), name = "Actual Delay") +
  geom_vline(xintercept = 0.5, linetype = "dashed", color = "red", linewidth = 1) +
  labs(
    title = "Predicted Probabilities by True Delay Label",
    x = "Predicted Probability (DEP_DEL15 = 1)",
    y = "Count of Flights"
  ) +
  theme_minimal()

# Variable Importance plot
varImpPlot(rf_final, main = "Variable Importance (Random Forest)")


# ---------------------xgboost---------------
library(xgboost)
library(caret)
library(dplyr)
library(pROC)
library(ggplot2)

# Set target and predictors
target <- "DEP_DEL15"
predictors <- setdiff(names(train_clean), c(target, "FL_DATE", "TAIL_NUM"))

# Filter missing values and ensure factor type
train_clean <- train_clean %>% filter(DEP_DEL15 %in% c(0, 1)) %>% drop_na(all_of(predictors))
val_clean <- val_clean %>% filter(DEP_DEL15 %in% c(0, 1)) %>% drop_na(all_of(predictors))
train_clean$DEP_DEL15 <- as.factor(train_clean$DEP_DEL15)
val_clean$DEP_DEL15 <- as.factor(val_clean$DEP_DEL15)

# Combine for consistent one-hot encoding
combined <- bind_rows(
  mutate(train_clean, set = "train"),
  mutate(val_clean, set = "val")
) %>% select(-FL_DATE, -TAIL_NUM)

# Ensure DEP_DEL15 is numeric 0/1
combined$DEP_DEL15 <- as.numeric(as.factor(combined$DEP_DEL15)) - 1

# Create one-hot encoded matrix
dummies <- dummyVars(DEP_DEL15 ~ ., data = combined)
x_all <- predict(dummies, newdata = combined) %>% as.matrix()
y_all <- combined$DEP_DEL15

# Split back into train and validation
x_train <- x_all[combined$set == "train", ]
x_val <- x_all[combined$set == "val", ]
y_train <- y_all[combined$set == "train"]
y_val <- y_all[combined$set == "val"]

# Convert to DMatrix
dtrain <- xgb.DMatrix(data = x_train, label = y_train)
dval <- xgb.DMatrix(data = x_val, label = y_val)
# Expanded hyperparameter grid
param_grid <- expand.grid(
  eta = c(0.05, 0.1, 0.3),
  max_depth = c(3, 6, 10),
  min_child_weight = c(1, 5),
  subsample = c(0.8, 1.0),
  colsample_bytree = c(0.8, 1.0)
)

param_grid$train_auc <- NA
param_grid$train_auc <- NA
param_grid$val_auc <- NA

# Tuning loop
for (i in 1:nrow(param_grid)) {
  params <- list(
    booster = "gbtree",
    objective = "binary:logistic",
    eval_metric = "auc",
    eta = param_grid$eta[i],
    max_depth = param_grid$max_depth[i],
    min_child_weight = param_grid$min_child_weight[i],
    subsample = param_grid$subsample[i],
    colsample_bytree = param_grid$colsample_bytree[i]
  )
  
  model <- xgb.train(params = params, data = dtrain, nrounds = 100, verbose = 0)
  train_preds <- predict(model, newdata = dtrain)
  val_preds <- predict(model, newdata = dval)
  
  param_grid$train_auc[i] <- auc(y_train, train_preds)
  param_grid$val_auc[i] <- auc(y_val, val_preds)
}

# Select best params
best <- dplyr::slice(dplyr::arrange(param_grid, desc(val_auc)), 1)
print(best)

# Train final model with best parameters
best_params <- list(
  booster = "gbtree",
  objective = "binary:logistic",
  eval_metric = "auc",
  eta = best$eta,
  max_depth = best$max_depth,
  min_child_weight = best$min_child_weight,
  subsample = best$subsample,
  colsample_bytree = best$colsample_bytree
)
rf_final <- xgb.train(params = best_params, data = dtrain, nrounds = 100, verbose = 0)

# Predict on validation
val_probs <- predict(rf_final, newdata = dval)
val_preds <- factor(ifelse(val_probs >= 0.5, "1", "0"), levels = c("0", "1"))
actual <- factor(y_val, levels = c(0, 1))
levels(actual) <- c("0", "1")

# Evaluation
cm <- confusionMatrix(val_preds, actual, positive = "1")
auc_val <- auc(y_val, val_probs)
train_auc <- auc(y_train, predict(rf_final, newdata = dtrain))

print(cm$table)
cat("\nTrain AUC:", round(train_auc, 4), "\n")
cat("Validation AUC:", round(auc_val, 4), "\n")
cat("Accuracy:", round(cm$overall["Accuracy"], 4), "\n")
cat("Precision:", round(cm$byClass["Precision"], 4), "\n")
cat("Recall:", round(cm$byClass["Recall"], 4), "\n")
cat("F1 Score:", round(cm$byClass["F1"], 4), "\n")

# Histogram plot
val_clean$predicted_prob <- val_probs
val_clean$actual_label <- actual

ggplot(val_clean, aes(x = predicted_prob, fill = actual_label)) +
  geom_histogram(binwidth = 0.025, position = "identity", alpha = 0.6, color = "black") +
  scale_fill_manual(values = c("0" = "lightgreen", "1" = "salmon"), name = "Actual Delay") +
  geom_vline(xintercept = 0.5, linetype = "dashed", color = "red", linewidth = 1) +
  labs(
    title = "Predicted Probabilities by True Delay Label",
    x = "Predicted Probability (DEP_DEL15 = 1)",
    y = "Count of Flights"
  ) +
  theme_minimal()


